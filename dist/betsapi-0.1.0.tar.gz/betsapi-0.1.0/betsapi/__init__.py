
__version__ = '0.0.01'
__app_name__ = 'betsapi'