from betsapi import cli, __app_name__

def app():
    cli.app(prog_name=__app_name__)